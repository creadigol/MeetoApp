package Adapters;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.display.RoundedBitmapDisplayer;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import Models.Wishlist_item;
import Models.Yourlist_item;
import Utils.AppUrl;
import Utils.ParamsKey;
import Utils.PreferenceSettings;
import creadigol.com.meetto.MeettoApplication;
import creadigol.com.meetto.R;
import creadigol.com.meetto.SeminarDetail_Activity;


/**
 * Created by Creadigol on 12-09-2016.
 */
public class Wishlist_Adapter extends RecyclerView.Adapter<Wishlist_Adapter.MyViewHolder> {

    PreferenceSettings mPreferenceSettings;
    String seminarid;
    Context context;
    ArrayList<Wishlist_item> wishlist_items;
    View.OnClickListener onClickListener;
    View.OnLongClickListener onLongClickListener;

    public Wishlist_Adapter(Context context, ArrayList<Wishlist_item> yourlistItems, View.OnClickListener onClickListener,View.OnLongClickListener onLongClickListener) {
        this.context = context;
        this.wishlist_items = yourlistItems;
        this.onClickListener = onClickListener;
        this.onLongClickListener=onLongClickListener;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.custome_wishlist_activity, parent, false);
        MyViewHolder myViewHolder = new MyViewHolder(view);
        mPreferenceSettings=MeettoApplication.getInstance().getPreferenceSettings();
        return myViewHolder;

    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {

        final Wishlist_item list = wishlist_items.get(position);

        holder.tv_name.setText(list.getSeminar_name());
        holder.tv_date.setText(list.getDate());


        MeettoApplication.getInstance().getImageLoader().displayImage(list.getSeminar_image(), holder.imvlist, getDisplayImageOptions());

        holder.viewlist.setTag(position);
        holder.viewlist.setOnClickListener(onClickListener);

        holder.viewlist.setOnLongClickListener(onLongClickListener);
    }

    public DisplayImageOptions getDisplayImageOptions() {
        DisplayImageOptions options = new DisplayImageOptions.Builder().cacheInMemory(true)
                .cacheOnDisk(true).resetViewBeforeLoading(true)
                .showImageForEmptyUri(R.drawable.nophoto)
                .showImageOnFail(R.drawable.nophoto)
                .showImageOnLoading(R.drawable.nophoto)
                .cacheInMemory(true)
                .cacheOnDisk(true)
                .considerExifParams(true)
                .bitmapConfig(Bitmap.Config.RGB_565)
                .displayer(new RoundedBitmapDisplayer(0))
                .build();
        return options;
    }

    @Override
    public int getItemCount() {
        return wishlist_items.size();
    }


    class MyViewHolder extends RecyclerView.ViewHolder {

        public TextView tv_name, tv_date;
        public ImageView imvlist;
        public CardView viewlist;

        public MyViewHolder(View v) {
            super(v);
            tv_name = (TextView) v.findViewById(R.id.tv_wishlistname);
            tv_date = (TextView) v.findViewById(R.id.tv_wishlistdate);
            imvlist = (ImageView) v.findViewById(R.id.img_wishlist_image);
            viewlist = (CardView) v.findViewById(R.id.viewwishlist);

        }


    }

    public void modifyDataSet(ArrayList<Wishlist_item> searchObjects) {
        this.wishlist_items = searchObjects;
        this.notifyDataSetChanged();
    }

}