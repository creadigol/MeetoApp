package Models;

/**
 * Created by Creadigol on 19-09-2016.
 */
public class SimilerSeminaritem {

    String seminar_id,seminar_pic,seminar_name;

    public String getSeminar_id() {
        return seminar_id;
    }

    public void setSeminar_id(String seminar_id) {
        this.seminar_id = seminar_id;
    }

    public String getSeminar_name() {
        return seminar_name;
    }

    public void setSeminar_name(String seminar_name) {
        this.seminar_name = seminar_name;
    }

    public String getSeminar_pic() {
        return seminar_pic;
    }

    public void setSeminar_pic(String seminar_pic) {
        this.seminar_pic = seminar_pic;
    }
}
