package Models;

/**
 * Created by Vj on 7/16/2016.
 */

public interface IObjaec {

}
