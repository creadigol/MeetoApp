package Models;

/**
 * Created by Creadigol on 12-09-2016.
 */
public class Notification_item  {
String userid,subject;

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getUserid() {
        return userid;
    }

    public void setUserid(String userid) {
        this.userid = userid;
    }
}
