package Models;

/**
 * Created by binal on 19/2/16.
 */
public class User_data_item {
 String lang_id,lang_name;

    public String getLang_id() {
        return lang_id;
    }

    public void setLang_id(String lang_id) {
        this.lang_id = lang_id;
    }

    public String getLang_name() {
        return lang_name;
    }

    public void setLang_name(String lang_name) {
        this.lang_name = lang_name;
    }

    public String getSem_id() {
        return sem_id;
    }

    public void setSem_id(String sem_id) {
        this.sem_id = sem_id;
    }

    public String getSem_name() {
        return sem_name;
    }

    public void setSem_name(String sem_name) {
        this.sem_name = sem_name;
    }

    public String getFacility_id() {
        return facility_id;
    }

    public void setFacility_id(String facility_id) {
        this.facility_id = facility_id;
    }

    public String getFacility_name() {
        return facility_name;
    }

    public void setFacility_name(String facility_name) {
        this.facility_name = facility_name;
    }

    public String getIndustry_id() {
        return industry_id;
    }

    public void setIndustry_id(String industry_id) {
        this.industry_id = industry_id;
    }

    public String getIndustry_name() {
        return industry_name;
    }

    public void setIndustry_name(String industry_name) {
        this.industry_name = industry_name;
    }

    public String getAttendess_id() {
        return attendess_id;
    }

    public void setAttendess_id(String attendess_id) {
        this.attendess_id = attendess_id;
    }

    public String getAttendess_name() {
        return attendess_name;
    }

    public void setAttendess_name(String attendess_name) {
        this.attendess_name = attendess_name;
    }

    String sem_id,sem_name;
    String facility_id,facility_name;
    String industry_id,industry_name;
    String attendess_id,attendess_name;
}
