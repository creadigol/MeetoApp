package Fragments;

import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import Adapters.UserAttendess_Adapter;
import Adapters.Userindustry_Adapter;
import Adapters.Userseminartype_Adapter;
import Models.SeminarDetailsarrayitem;
import Models.Seminardetailsitem;
import Models.User_data_Object;
import Models.User_data_item;
import Utils.AppUrl;
import Utils.CommonUtils;
import Utils.Jsonkey;
import Utils.ParamsKey;
import Utils.PreferenceSettings;
import creadigol.com.meetto.MeettoApplication;
import creadigol.com.meetto.R;


/**
 * Created by Creadigol on 09-09-2016.
 */
public class AddSeminar_Fragment extends Fragment implements View.OnClickListener {
    Button btncount;
    EditText ed_totalseat;
    RecyclerView rv_attendess, rv_seminattype, rv_industry;
    String totalseat,  properttype;
    PreferenceSettings mPreferenceSettings;
    ArrayList<User_data_item> userDataObjects;
    ArrayList<User_data_item> userseminartype;
    ArrayList<User_data_item> userindustry;

    UserAttendess_Adapter userAttendess_adapter;
    Userseminartype_Adapter userseminartype_adapter;
    Userindustry_Adapter userindustry_adapter;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        mPreferenceSettings = MeettoApplication.getInstance().getPreferenceSettings();
        super.onCreate(savedInstanceState);
        MeettoApplication.addprefrence = 1;
        mPreferenceSettings.setIS_VISIBLE(false);

    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        if (mPreferenceSettings.getLUNGAUGE()) {
            MeettoApplication.language("ja");
        } else {
            MeettoApplication.language("en");
        }
        View view = inflater.inflate(R.layout.fragment_addseminar, container, false);
        btncount = (Button) view.findViewById(R.id.btncountinue);
        btncount.setOnClickListener(this);

        rv_attendess = (RecyclerView) view.findViewById(R.id.rv_seminartype);
        rv_seminattype = (RecyclerView) view.findViewById(R.id.rv_addattendess);
        rv_industry = (RecyclerView) view.findViewById(R.id.rv_addindustry);

        if (mPreferenceSettings.getEdit()) {
            reqseminardetail();
        }
        User_data();
        ed_totalseat = (EditText) view.findViewById(R.id.ed_totalseat);
        ed_totalseat.setText(mPreferenceSettings.getTotalseat());

        return view;
    }

    void setattendess() {
        if (userDataObjects.size() > 0 || userDataObjects != null) {
            if (userAttendess_adapter == null) {

                rv_attendess.setHasFixedSize(true);
                //Set RecyclerView type according to intent value
                GridLayoutManager gridLayoutManager = new GridLayoutManager(getActivity(), 2);

                rv_attendess.setHasFixedSize(true);
                rv_attendess.setLayoutManager(gridLayoutManager);
                userAttendess_adapter = new UserAttendess_Adapter(getActivity(), userDataObjects);
                rv_attendess.setAdapter(userAttendess_adapter);
            } else {
                userAttendess_adapter.modifyDataSet(userDataObjects);
            }
        }
    }

    void setSeminattype() {
        if (userseminartype.size() > 0 || userseminartype != null) {
            if (userseminartype_adapter == null) {

                rv_seminattype.setHasFixedSize(true);
                //Set RecyclerView type according to intent value
                GridLayoutManager gridLayoutManager = new GridLayoutManager(getActivity(), 2);

                rv_seminattype.setHasFixedSize(true);
                rv_seminattype.setLayoutManager(gridLayoutManager);
                userseminartype_adapter = new Userseminartype_Adapter(getActivity(), userseminartype);
                rv_seminattype.setAdapter(userseminartype_adapter);
            } else {
                userseminartype_adapter.modifyDataSet(userseminartype);
            }
        }
    }

    void setIndustrys() {
        if (userindustry.size() > 0 || userindustry != null) {
            if (userindustry_adapter == null) {


                rv_industry.setHasFixedSize(true);
                //Set RecyclerView type according to intent value
                GridLayoutManager gridLayoutManager = new GridLayoutManager(getActivity(), 2);

                rv_industry.setHasFixedSize(true);
                rv_industry.setLayoutManager(gridLayoutManager);
                userindustry_adapter = new Userindustry_Adapter(getActivity(), userindustry);
                rv_industry.setAdapter(userindustry_adapter);
            } else {
                userindustry_adapter.modifyDataSet(userindustry);
            }
        }
    }

    public void User_data() {
        final ProgressDialog mProgressDialog = new ProgressDialog(getActivity());
        mProgressDialog.setMessage("Loading.....");
        mProgressDialog.setCancelable(false);
        mProgressDialog.show();

        StringRequest jsonObjectRequest = new StringRequest(Request.Method.POST, AppUrl.URL_USER_DATA, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    Log.e("addseminar", "Response: " + response);

                    JSONObject jsonObject = new JSONObject(response);
                    User_data_Object user_data_object = new User_data_Object();
                    try {
                        user_data_object.setStatus_code(jsonObject.getInt(Jsonkey.statusCode));
                    } catch (JSONException e) {
                        user_data_object.setStatus_code(0);
                    }

                    user_data_object.setMessage(jsonObject.optString(Jsonkey.message));

                    try {
                        user_data_object.setSemtype(jsonObject.getJSONArray(Jsonkey.seminartype));
                    } catch (JSONException e) {
                        user_data_object.setSemtype(null);
                    }
                    try {
                        user_data_object.setAttendess(jsonObject.getJSONArray(Jsonkey.purpose));
                    } catch (JSONException e) {
                        user_data_object.setSemtype(null);
                    }

                    try {
                        user_data_object.setgetIndustry(jsonObject.getJSONArray(Jsonkey.industrys));
                    } catch (JSONException e) {
                        user_data_object.setSemtype(null);
                    }
                    userseminartype = user_data_object.getSemtype();
                    userDataObjects = user_data_object.getAttendess();
                    userindustry = user_data_object.getIndustry();
                    setattendess();
                    setSeminattype();
                    setIndustrys();

                    mProgressDialog.dismiss();
                } catch (JSONException e) {
                    mProgressDialog.dismiss();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                mProgressDialog.dismiss();
                Log.e("Error_in", "onErrorResponse");
                showTryAgainAlert("" + getResources().getString(R.string.network1) + "", getResources().getString(R.string.network2) + "");
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                if (mPreferenceSettings.getLUNGAUGE()) {
                    params.put(ParamsKey.KEY_USER_LANG, "ja");
                }
                if (mPreferenceSettings.getLUNGAUGE() == false) {
                    params.put(ParamsKey.KEY_USER_LANG, "en");

                }
                Log.e("addseminar", "reqSearchLocationData params: " + params.toString());

                return params;
            }
        };

        MeettoApplication.getInstance().addToRequestQueue(jsonObjectRequest, "addseminar");
    }


    public void validation() {


        totalseat = ed_totalseat.getText().toString().trim();
        if (totalseat.equals("") || totalseat.length() == 0) {
            ed_totalseat.setError("Enter available seat");
        } else {
            PreferenceSettings mPreferenceSettings = MeettoApplication.getInstance().getPreferenceSettings();
            mPreferenceSettings.setProperttype(properttype);
            Log.e("property", "" + mPreferenceSettings.getProperttype());

            String seminarattendees = "", seminarindustry = "";
            if (MeettoApplication.attendess != null && MeettoApplication.attendess.size() > 0) {
                for (int i = 0; i < MeettoApplication.attendess.size(); i++) {
                    seminarattendees = seminarattendees + MeettoApplication.attendess.get(i) + ",";
                    mPreferenceSettings.setPurpose(seminarattendees);
                }
                Log.e("attendess", "" + mPreferenceSettings.getPurpose());
                Log.e("attendess", "" + seminarattendees);
            }
            if (MeettoApplication.industry != null && MeettoApplication.industry.size() > 0) {
                for (int i = 0; i < MeettoApplication.industry.size(); i++) {
                    seminarindustry = seminarindustry + MeettoApplication.industry.get(i) + ",";
                    mPreferenceSettings.setIndustry(seminarindustry);
                }
                Log.e("industry", "" + mPreferenceSettings.getIndustry());
            }
            mPreferenceSettings.setTotalseat(totalseat);
            getFragmentManager().beginTransaction().remove(getFragmentManager().findFragmentById(R.id.fragment_container)).commit();
            FragmentManager fragmentManager = getFragmentManager();
            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
            AddSeminarList_Fragment Add = new AddSeminarList_Fragment();
            fragmentTransaction.add(R.id.fragment_container, Add, "Addseminar_Fragment");
            fragmentTransaction.commit();
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btncountinue:
                validation();
                break;
        }
    }

    public void reqseminardetail() {
        final ProgressDialog mProgressDialog = new ProgressDialog(getActivity());
        mProgressDialog.setMessage("Loading.....");
        mProgressDialog.setCancelable(false);
        mProgressDialog.show();

        StringRequest jsonObjectRequest = new StringRequest(Request.Method.POST, AppUrl.URL_SEMINAR_DETAILS2, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                mProgressDialog.dismiss();
                try {
                    Log.e("add", "Response: " + response);
                    JSONObject jsonObject = new JSONObject(response);
                    Seminardetailsitem seminardetailsitem = new Seminardetailsitem();

                    try {
                        seminardetailsitem.setStatus_code(jsonObject.getInt(Jsonkey.statusCode));
                    } catch (JSONException e) {
                        seminardetailsitem.setStatus_code(0);
                    }

                    seminardetailsitem.setMessage(jsonObject.optString(Jsonkey.message));


                    if (seminardetailsitem.getStatus_code() == 1) {
                        JSONObject jsonObjectOutlet = jsonObject.getJSONObject(Jsonkey.seminardeatil_key);

                        seminardetailsitem.setSeminar_id(jsonObjectOutlet.optString(Jsonkey.seminarid));
                        seminardetailsitem.setSeminar_total_seat(jsonObjectOutlet.optString(Jsonkey.seminar_seat));
                        seminardetailsitem.setSeminar_type(jsonObjectOutlet.optString(Jsonkey.seminar_type));

                        mPreferenceSettings.setIS_VISIBLE(true);
                        try {
                            JSONArray attendees = jsonObject.getJSONArray(Jsonkey.seminar_purpose);
                            seminardetailsitem.setattendees(attendees);
                            Log.e("attendees", " b" + seminardetailsitem.getattendees().size());
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                        try {
                            JSONArray industry = jsonObject.getJSONArray(Jsonkey.industry);
                            seminardetailsitem.setIndustry(industry);
                            Log.e("industry", " b" + seminardetailsitem.getIndustry().size());
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        //set outlet detail
                        setOutletdetail(seminardetailsitem);
                        mProgressDialog.dismiss();
                    } else if (seminardetailsitem.getStatus_code() == 0 || seminardetailsitem.getStatus_code() == 2) {
                        mProgressDialog.dismiss();
                        CommonUtils.showToast(seminardetailsitem.getMessage());
                        //showTryAgainAlert("Info", outletObject.getMessage() + " Try again!");
                    } else {
                        mProgressDialog.dismiss();

                        Log.e("Error_in", "Error_else");
                    }
                } catch (JSONException e) {
                    mProgressDialog.dismiss();
                    Log.e("Error_in", "catch");

                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                mProgressDialog.dismiss();
                Log.e("Error_in", "onErrorResponse");

                showTryAgainAlert("" + getResources().getString(R.string.network1) + "", getResources().getString(R.string.network2) + "");
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                PreferenceSettings mPreferenceSettings = MeettoApplication.getInstance().getPreferenceSettings();

                Map<String, String> params = new HashMap<String, String>();
                params.put(ParamsKey.KEY_SEMINAR_ID, mPreferenceSettings.getSeminar_id());
                params.put(ParamsKey.KEY_USERID, mPreferenceSettings.getUserId());
                if (mPreferenceSettings.getLUNGAUGE()) {
                    params.put(ParamsKey.KEY_USER_LANG, "ja");
                }
                if (mPreferenceSettings.getLUNGAUGE() == false) {
                    params.put(ParamsKey.KEY_USER_LANG, "en");

                }
                Log.e("Add", "reqOutletData params: " + params.toString());

                return params;
            }
        };

        MeettoApplication.getInstance().addToRequestQueue(jsonObjectRequest, "add");
    }

    public void showTryAgainAlert(String title, String message) {
        CommonUtils.showAlertWithNegativeButton(getActivity(), title, message, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();

                if (CommonUtils.isNetworkAvailable())
                    reqseminardetail();
                else
                    CommonUtils.showToast("" + getResources().getString(R.string.network3));

            }
        });
    }

    public void setOutletdetail(final Seminardetailsitem seminardetails) {
        ed_totalseat.setText(seminardetails.getSeminar_total_seat());

        if (seminardetails.getSeminar_type() != null) {
            MeettoApplication.seminattype.add(seminardetails.getSeminar_type());
        }
        if (seminardetails.getattendees() != null && seminardetails.getattendees().size() > 0) {
            setAttendees(seminardetails.getattendees());
        }
        if (seminardetails.getIndustry() != null && seminardetails.getIndustry().size() > 0) {
            setIndustry(seminardetails.getIndustry());
        }
    }

    public void setAttendees(ArrayList<SeminarDetailsarrayitem> attendees) {
        if (attendees != null) {

            for (SeminarDetailsarrayitem attendeesobject : attendees) {
                String attendess = attendeesobject.getSeminar_purpose();
                MeettoApplication.attendess.add(attendess);
            }
        }
    }

    public void setIndustry(ArrayList<SeminarDetailsarrayitem> industrys) {

        if (industrys != null) {

            for (SeminarDetailsarrayitem Industryobject : industrys) {
                String industry = Industryobject.getIndustry();
                Log.e("industry",""+Industryobject.getIndustry());
                MeettoApplication.industry.add(industry);
                Log.e("industry",""+MeettoApplication.industry);
            }
        }

    }
}