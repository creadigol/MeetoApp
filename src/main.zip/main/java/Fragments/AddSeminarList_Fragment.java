package Fragments;

import android.annotation.TargetApi;
import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.provider.Settings;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.util.Base64;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import App.MyApplication;
import Utils.AppUrl;
import Utils.ParamsKey;
import Utils.PreferenceSettings;
import creadigol.com.meetto.DisplayCropingImage;
import creadigol.com.meetto.MeettoApplication;
import creadigol.com.meetto.R;
import creadigol.com.meetto.YourListing_Activity;

public class AddSeminarList_Fragment extends Fragment implements View.OnClickListener {
    AddSeminarDetail_Fragment objfragmnet;
    android.app.FragmentTransaction ft;
    FragmentManager fragment;
    Bundle intent;
    String seminar_id, encodedImage;
    public static final String EXTRA_KEY_SEMINAR_ID = "seminar_id";
    PreferenceSettings mPreferenceSettings;
    AlertDialog alert;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        MeettoApplication.addprefrence = 2;
        mPreferenceSettings = MeettoApplication.getInstance().getPreferenceSettings();
        objfragmnet = new AddSeminarDetail_Fragment();
        fragment = getFragmentManager();
        ft = fragment.beginTransaction();
        intent = new Bundle();
        seminar_id = intent.getString("seminar_id");
        try {
            Log.e("adddata", "" + mPreferenceSettings.getProperttype() + "," + mPreferenceSettings.getPurpose() + "," + mPreferenceSettings.getTotalseat());
            Log.e("overview", "tagline" + mPreferenceSettings.getTagline() + ",desc" + mPreferenceSettings.getSeminardesc());
        } catch (Exception p) {
            Log.e("Error", "catch");
        }
    }

    LinearLayout ll_contact, ll_calender, ll_overview, ll_photo, ll_facilities, ll_listing, ll_location;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        if (mPreferenceSettings.getLUNGAUGE()) {
            MeettoApplication.language("ja");
        } else {
            MeettoApplication.language("en");
        }
        View view = inflater.inflate(R.layout.fragment_addseminar_list, container, false);

        ll_contact = (LinearLayout) view.findViewById(R.id.ll_contact);
        ll_calender = (LinearLayout) view.findViewById(R.id.ll_calandarlist);
        ll_overview = (LinearLayout) view.findViewById(R.id.ll_overviewlist);
        ll_photo = (LinearLayout) view.findViewById(R.id.ll_photolist);
        ll_facilities = (LinearLayout) view.findViewById(R.id.ll_Amenitieslist);
//        ll_listing = (LinearLayout) view.findViewById(R.id.ll_listinglist);
        ll_location = (LinearLayout) view.findViewById(R.id.ll_locationlist);

        ll_contact.setOnClickListener(this);
        ll_calender.setOnClickListener(this);
        ll_overview.setOnClickListener(this);
        ll_photo.setOnClickListener(this);
        ll_facilities.setOnClickListener(this);
//        ll_listing.setOnClickListener(this);
        ll_location.setOnClickListener(this);

        Button btn_save = (Button) view.findViewById(R.id.btn_addsave);
        if (mPreferenceSettings.getIS_VISIBLE()) {
            btn_save.setVisibility(View.VISIBLE);
        }
        btn_save.setOnClickListener(this);

        return view;
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.ll_contact:
                getFragmentManager().beginTransaction().remove(getFragmentManager().findFragmentById(R.id.fragment_container)).commit();
                intent.putString("seminar", "contact");
                objfragmnet.setArguments(intent);
                ft.add(R.id.fragment_container, objfragmnet);
                ft.commit();
                break;

            case R.id.ll_calandarlist:
                getFragmentManager().beginTransaction().remove(getFragmentManager().findFragmentById(R.id.fragment_container)).commit();
                intent.putString("seminar", "calender");
                objfragmnet.setArguments(intent);
                ft.add(R.id.fragment_container, objfragmnet);
                ft.commit();
                break;

            case R.id.ll_overviewlist:
                getFragmentManager().beginTransaction().remove(getFragmentManager().findFragmentById(R.id.fragment_container)).commit();
                intent.putString("seminar", "overview");
                objfragmnet.setArguments(intent);
                ft.replace(R.id.fragment_container, objfragmnet);
                ft.commit();
                break;
            case R.id.ll_photolist:
                getFragmentManager().beginTransaction().remove(getFragmentManager().findFragmentById(R.id.fragment_container)).commit();
                intent.putString("seminar", "photo");
                objfragmnet.setArguments(intent);
                ft.replace(R.id.fragment_container, objfragmnet);
                ft.commit();
                break;

            case R.id.ll_Amenitieslist:
                getFragmentManager().beginTransaction().remove(getFragmentManager().findFragmentById(R.id.fragment_container)).commit();
                intent.putString("seminar", "facilities");
                objfragmnet.setArguments(intent);
                ft.replace(R.id.fragment_container, objfragmnet);
                ft.commit();
                break;

//            case R.id.ll_listinglist:
//                getFragmentManager().beginTransaction().remove(getFragmentManager().findFragmentById(R.id.fragment_container)).commit();
//                intent.putString("seminar", "listing");
//                objfragmnet.setArguments(intent);
//                ft.replace(R.id.fragment_container, objfragmnet);
//                ft.commit();
//                break;


            case R.id.ll_locationlist:
                getFragmentManager().beginTransaction().remove(getFragmentManager().findFragmentById(R.id.fragment_container)).commit();
                intent.putString("seminar", "location");
                objfragmnet.setArguments(intent);
                ft.replace(R.id.fragment_container, objfragmnet);
                ft.commit();
                break;

            case R.id.btn_addsave:
                try {
                    Log.e("clander", "formdate" + mPreferenceSettings.getFromdate() + ",todate" + mPreferenceSettings.getTodate() + ",stattime" + mPreferenceSettings.getStarttime() + ",endtime" + mPreferenceSettings.getEndtime() + ",facility" + mPreferenceSettings.getFacility());
                    final LocationManager manager = (LocationManager) getActivity().getSystemService(Context.LOCATION_SERVICE);
                    if (!manager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                        buildAlertMessageNoGps();
                    } else {
                        addseminar();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }

                break;
        }
    }

    private void buildAlertMessageNoGps() {
        final AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setTitle("info");
        builder.setMessage("Your GPS seems to be disabled, do you want to enable it?")
                .setCancelable(false)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    public void onClick(@SuppressWarnings("unused") final DialogInterface dialog, @SuppressWarnings("unused") final int id) {
                        Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                        startActivity(intent);

                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    public void onClick(final DialogInterface dialog, @SuppressWarnings("unused") final int id) {
                        dialog.cancel();

                    }
                });
        alert = builder.create();
        alert.show();
    }

    public Bitmap getResizedBitmap(Bitmap image, int maxSize) {
        int width = image.getWidth();
        int height = image.getHeight();

        float bitmapRatio = (float) width / (float) height;
        if (bitmapRatio > 0) {
            width = maxSize;
            height = (int) (width / bitmapRatio);
        } else {
            height = maxSize;
            width = (int) (height * bitmapRatio);
        }
        return Bitmap.createScaledBitmap(image, width, height, true);
    }

    public void addseminar() {
        //get path from select image
        final ProgressDialog mProgressDialog = new ProgressDialog(getActivity());
        mProgressDialog.setMessage("Loading.....");
        mProgressDialog.setCancelable(false);
        mProgressDialog.show();

        StringRequest jsonObjectRequest = new StringRequest(Request.Method.POST, AppUrl.URL_ADDSEMINAR, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.e("User update response", response);
                mProgressDialog.dismiss();

                try {
                    JSONObject responseObj = new JSONObject(response);
                    String message = responseObj.getString("message");

                    int status_code = responseObj.getInt("status_code");
                    if (status_code == 1) {

                        MeettoApplication.photo = null;
                        MeettoApplication.count = null;
                        Toast.makeText(getActivity(), message, Toast.LENGTH_SHORT).show();
                        Intent i = new Intent(getActivity(), YourListing_Activity.class);
                        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        startActivity(i);
                        getActivity().finish();
                    } else if (status_code == 0) {
                        Toast.makeText(getActivity(), message, Toast.LENGTH_SHORT).show();
                    } else {
                        mProgressDialog.dismiss();
                        Log.e("Error_in", "else");
                    }

                } catch (JSONException e) {
                    mProgressDialog.dismiss();
                    Log.e("Error_in", "catch");
//                    showTryAgainAlert("Info", "Network error" + " try again!");
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                mProgressDialog.dismiss();
                MeettoApplication.photo = null;
                Log.e("Error_in", "onErrorResponse");
//                showTryAgainAlert("Info", "Network error, Please try again!");
            }
        }) {
            @TargetApi(Build.VERSION_CODES.KITKAT)
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();

                params.put(ParamsKey.KEY_USERID, mPreferenceSettings.getUserId());
                params.put(ParamsKey.KEY_TITLE, mPreferenceSettings.getTitle());
                params.put(ParamsKey.KEY_TAGLINE, mPreferenceSettings.getTagline());
                params.put(ParamsKey.KEY_DESC, mPreferenceSettings.getSeminardesc());
                params.put(ParamsKey.KEY_TOTALSEAT, mPreferenceSettings.getTotalseat());
                params.put(ParamsKey.KEY_ADDRESS, mPreferenceSettings.getSeminaraddress());
                params.put(ParamsKey.KEY_SEMINAR_TYPE, mPreferenceSettings.getProperttype());
                params.put(ParamsKey.KEY_COUNTRYID, mPreferenceSettings.getCountry());
                params.put(ParamsKey.KEY_STATEID, mPreferenceSettings.getState());
                params.put(ParamsKey.KEY_CITYID, mPreferenceSettings.getCity());
                params.put(ParamsKey.KEY_ZIPCODE, mPreferenceSettings.getZipcode());
                params.put(ParamsKey.KEY_PHONENUMBER, mPreferenceSettings.getContactno());
                params.put(ParamsKey.KEY_HOSTNAME, mPreferenceSettings.getHostname());
                params.put(ParamsKey.KEY_CONTACTEMAIL, mPreferenceSettings.getContactemail());
                params.put(ParamsKey.KEY_PURPOSEID, mPreferenceSettings.getPurpose());




                String givenDateTodate = mPreferenceSettings.getTodate();
                String givenDateFromdate = mPreferenceSettings.getFromdate();
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm");
                Date date = null;
                Date date2 = null;
                try {
                    date = sdf.parse(givenDateFromdate);
                    date2 = sdf.parse(givenDateTodate);
                } catch (ParseException e) {
                    e.printStackTrace();
                }
                Log.e("seminar",""+date.getTime());

                System.out.println("Date in milli :: " + date);
                System.out.println("Date in milli :: " + date2);
                params.put(ParamsKey.KEY_FROMDATE, String.valueOf(date.getTime()));
                params.put(ParamsKey.KEY_TODATE, String.valueOf(date2.getTime()));
//                params.put(ParamsKey.KEY_FROMTIME, mPreferenceSettings.getStarttime());
//                params.put(ParamsKey.KEY_TOTIME, mPreferenceSettings.getEndtime());
                params.put(ParamsKey.KEY_FACILITYID, mPreferenceSettings.getFacility());
                params.put(ParamsKey.KEY_INDUSTRY_ID, mPreferenceSettings.getIndustry());
                params.put("latitude", String.valueOf(MeettoApplication.getInstance().getLocationTracker().getLatitude()));
                params.put("longitude", String.valueOf(MeettoApplication.getInstance().getLocationTracker().getLongitude()));

                if (mPreferenceSettings.getLUNGAUGE()) {
                    params.put(ParamsKey.KEY_USER_LANG, "ja");
                }
                if (mPreferenceSettings.getLUNGAUGE() == false) {
                    params.put(ParamsKey.KEY_USER_LANG, "en");

                }
                if (mPreferenceSettings.getEdit()) {
                    params.put(ParamsKey.KEY_EDIT, "true");
                    params.put(ParamsKey.KEY_SEMINAR_ID, mPreferenceSettings.getSeminar_id());
                }
                if (MeettoApplication.photo != null) {
                    params.put(ParamsKey.KEY_PHOTOCOUNT, String.valueOf(MeettoApplication.photo.size()));
                    File file;
                    for (int k = 0; k < MeettoApplication.photo.size(); k++) {
                        file = new File(MeettoApplication.photo.get(k));
                        if (file != null && file.exists()) {

                            Bitmap bm = BitmapFactory.decodeFile(MeettoApplication.photo.get(k));
                            Log.e("Size 1 ", bm.getAllocationByteCount() + " ");

                            ByteArrayOutputStream baos = new ByteArrayOutputStream();
                            if (bm.getAllocationByteCount() > 100000) {
                                bm = getResizedBitmap(bm, 400);
                                bm.compress(Bitmap.CompressFormat.JPEG, 100, baos);
                                Log.e("Size 2 ", bm.getAllocationByteCount() + " ");
                            } else {
                                bm.compress(Bitmap.CompressFormat.JPEG, 100, baos);
                                Log.e("Size 3 ", bm.getAllocationByteCount() + " ");
                            }
//bm is the bitmap object
                            byte[] b = baos.toByteArray();
                            encodedImage = Base64.encodeToString(b, Base64.DEFAULT);
//                            params.put("image" + (k),encodedImage);
                            int i = k + 1;
                            params.put(ParamsKey.KEY_PHOTO + i, encodedImage);


                            Log.e("Image", " " + encodedImage);

                        }

//                    }
//                }
//  params.put(ParamsKey.KEY_PHOTO, "");
                    }
                    for (int k = 0; k < MeettoApplication.count.size(); k++) {
                        int i = k + 1;
                        params.put(ParamsKey.KEY_Rotate + i, String.valueOf(MeettoApplication.count.get(k)));
                        Log.e("count",""+ ParamsKey.KEY_Rotate + i+ "all"+String.valueOf(MeettoApplication.count.get(k)));
                    }

                } else {
                    params.put(ParamsKey.KEY_PHOTO, mPreferenceSettings.getseminar_pic());
                    params.put(ParamsKey.KEY_PHOTOCOUNT, mPreferenceSettings.getphotocount());
                }

                Log.e("addseminar", "reqOutletData params: " + params.toString());

                return params;
            }
        };

        MeettoApplication.getInstance().addToRequestQueue(jsonObjectRequest, "addseminar");
    }

    @Override
    public void onResume() {

        super.onResume();

        getView().setFocusableInTouchMode(true);
        getView().requestFocus();
        getView().setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {

                if (event.getAction() == KeyEvent.ACTION_UP && keyCode == KeyEvent.KEYCODE_BACK) {
                    getFragmentManager().beginTransaction().remove(getFragmentManager().findFragmentById(R.id.fragment_container)).commit();
                    FragmentManager fragmentManager = getFragmentManager();
                    FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                    AddSeminar_Fragment Add = new AddSeminar_Fragment();
                    fragmentTransaction.add(R.id.fragment_container, Add, "Addseminar_Fragment");
                    fragmentTransaction.commit();
                    return true;
                }
                return false;
            }
        });
    }
}