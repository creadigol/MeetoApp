package creadigol.com.meetto;

import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Color;
import android.os.Bundle;
import android.preference.Preference;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.TextView;

import java.util.Locale;

import Utils.PreferenceSettings;

/**
 * Created by ravi on 27-10-2016.
 */

public class Language_Selection_activity extends AppCompatActivity implements View.OnClickListener {
    LinearLayout ll_english,ll_japanese,ll_setlng;
    TextView skip,tv_eng,tv_jp,tv_submited;
    String launguge;
    PreferenceSettings mPreferenceSettings;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        if(mPreferenceSettings.getLUNGAUGE()){
//            MeettoApplication.language("ja");
//        }else{
//            MeettoApplication.language("en");
//        }
        setContentView(R.layout.activity_language);
        ll_setlng=(LinearLayout)findViewById(R.id.ll_setlng);
        tv_eng=(TextView) findViewById(R.id.rb_english);
        tv_jp=(TextView) findViewById(R.id.rb_japanese);

        skip=(TextView)findViewById(R.id.skip_lng);

        tv_submited=(TextView)findViewById(R.id.tv_submited);

        skip.setOnClickListener(this);
        ll_setlng.setOnClickListener(this);

        mPreferenceSettings=MeettoApplication.getInstance().getPreferenceSettings();

        tv_eng.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                String languageToLoad  = "en";
//                Locale locale = new Locale(languageToLoad);
//                Locale.setDefault(locale);
//                Configuration config = new Configuration();
//                config.locale = locale;
//                getApplicationContext().getResources().updateConfiguration(config,getApplicationContext().getResources().getDisplayMetrics());

                mPreferenceSettings.setLUNGAUGE(false);
                MeettoApplication.language("en");
//                setContentView(R.layout.activity_language);
                Intent intent = new Intent(Language_Selection_activity.this, Splash_Activity.class);
                intent.putExtra("Login", "true");
                intent.addFlags(intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
                finish();
//                tv_eng.setTextColor(Color.BLUE);
//                tv_jp.setTextColor(Color.BLACK);
            }
        });
        tv_jp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                String languageToLoad  = "ja";
//                Locale locale = new Locale(languageToLoad);
//                Locale.setDefault(locale);
//                Configuration config = new Configuration();
//                config.locale = locale;
//                getApplicationContext().getResources().updateConfiguration(config,getApplicationContext().getResources().getDisplayMetrics());
//
//                tv_jp.setTextColor(Color.BLUE);
//                tv_eng.setTextColor(Color.BLACK);
//                mPreferenceSettings.setLUNGAUGE(true);
//                setContentView(R.layout.activity_language);

                mPreferenceSettings.setLUNGAUGE(true);
                MeettoApplication.language("en");
//                setContentView(R.layout.activity_language);
                Intent intent = new Intent(Language_Selection_activity.this, Splash_Activity.class);
                intent.putExtra("Login", "true");
                intent.addFlags(intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
                finish();
//                tv_eng.setTextColor(Color.BLACK);
//                tv_jp.setTextColor(Color.BLUE);

            }
        });
    }



    @Override
    public void onClick(View v) {
        switch (v.getId())
        {
//            case R.id.tv_submited:
//                Log.e("lang","== "+mPreferenceSettings.getLUNGAUGE());
//                Intent intent = new Intent(Language_Selection_activity.this, Splash_Activity.class);
//                intent.putExtra("Login", "true");
//                startActivity(intent);
//                finish();
//                break;
            case R.id.skip_lng:
                finish();
                break;

        }

    }
}
