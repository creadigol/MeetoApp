package creadigol.com.meetto;

import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.widget.TextView;

import Fragments.AddSeminarList_Fragment;
import Fragments.AddSeminar_Fragment;
import Utils.PreferenceSettings;

/**
 * Created by Creadigol on 05-09-2016.
 */
public class Add_Seminar_Activity extends AppCompatActivity {
   PreferenceSettings mPreferenceSettings;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_addseminar);
        mPreferenceSettings=MeettoApplication.getInstance().getPreferenceSettings();
        FragmentManager fragmentManager = getFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        AddSeminar_Fragment Add = new AddSeminar_Fragment();
        fragmentTransaction.add(R.id.fragment_container, Add, "Addseminar_Fragment");
        fragmentTransaction.commit();
        Toolbar();
    }
    public void Toolbar() {
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar_addseminar);
        setSupportActionBar(toolbar);
        TextView tvCatTitle = (TextView) toolbar.findViewById(R.id.tv_toolbar_name);
        tvCatTitle.setText(R.string.add_Toolbar);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                if(MeettoApplication.addprefrence==1){
                    MeettoApplication.attendess.clear();
                    MeettoApplication.industry.clear();
                    MeettoApplication.seminattype.clear();
                    finish();
                }else if(MeettoApplication.addprefrence==2){
                    getFragmentManager().beginTransaction().remove(getFragmentManager().findFragmentById(R.id.fragment_container)).commit();
                    FragmentManager fragmentManager = getFragmentManager();
                    FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                    AddSeminar_Fragment Add = new AddSeminar_Fragment();
                    fragmentTransaction.add(R.id.fragment_container, Add, "Addseminar_Fragment");
                    fragmentTransaction.commit();
                }else if(MeettoApplication.addprefrence==3){
                    getFragmentManager().beginTransaction().remove(getFragmentManager().findFragmentById(R.id.fragment_container)).commit();
                    FragmentManager fragmentManager = getFragmentManager();
                    FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                    AddSeminarList_Fragment Add = new AddSeminarList_Fragment();
                    fragmentTransaction.add(R.id.fragment_container, Add, "Addseminar_Fragment");
                    fragmentTransaction.commit();
                }
        }
        return true;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        MeettoApplication.attendess.clear();
        MeettoApplication.industry.clear();
        MeettoApplication.seminattype.clear();
    }
}
