package Utils;

/**
 * Created by Ashfaq on 31-08-2016.
 */
public class AppUrl {
    public static final String APP_URL = "http://creadigol.biz/meeto/API/";

    //gcm id
    public static final String URL_SET_GCM_ID = APP_URL + "User/setgcm";

    public static final String URL_REGISTRATION = APP_URL+"User/register";
    public static final String URL_LOGIN= APP_URL+"User/login";
    public static final String URL_FORGOTPASSWORD= APP_URL+"User/forgotpass";
    public static final String URL_CHANGE_PASSWORD= APP_URL+"User/changepass";
    public static final String URL_HOME_PAGE= APP_URL+"Seminar/home";
    public static final String URL_SEMINAR_LIST= APP_URL+"Seminar/searchseminar";
    public static final String URL_SEMINAR_DETAILS= APP_URL+"Seminar/seminardetail";
    public static final String URL_SEMINAR_DETAILS2= APP_URL+"Seminar/ownseminardetail";
    public static final String URL_USER_LISTING= APP_URL+"User/userlisting";
    public static final String URL_USER_BOOKING= APP_URL+"User/userbooking";
    public static final String URL_BOOKING= APP_URL+"Seminar/seminarbooking";
    public static final String URL_ADD_WISHLIST = APP_URL+"Seminar/addtowishlist";
    public static final String URL_WISHLIST_VIEW = APP_URL+"User/userwishlist";
    public static final String URL_SEARCH_BY_STRING= APP_URL+"Seminar/searchseminarstring";
    public static final String URL_USER_PROFILE= APP_URL+"User/userprofile";
    public static final String URL_DELETE_WISHLIST= APP_URL+"User/deletewishlist";
    public static final String URL_DELETE_BOOKING= APP_URL+"User/deletebooking";
    public static final String URL_DELETE_LISTING= APP_URL+"User/deleteseminar";
    public static final String URL_NOTIFICATION= APP_URL+"User/notification";
    public static final String URL_VERIFYEMAIL= APP_URL+"User/verifyemail";
    public static final String URL_ADDSEMINAR= APP_URL+"Seminar/addseminar";
    public static final String URL_SEMINARBOOKING_LIST= APP_URL+"Seminar/seminarbookinglist";
    public static final String URL_ACCEPT_DECLINE= APP_URL+"Seminar/acceptdeclineseminar";
    public static final String URL_DOWNLOAD= APP_URL+"Seminar/booking_ticket_download";
    public static final String URL_REVIEW= APP_URL+"User/user_review";
    public static final String URL_GETREVIEW= APP_URL+"User/user_review_detail";

    public static final String URL_COUNTRY= APP_URL+"getcountry.php";
    public static final String URL_STATE= APP_URL+"getstate.php";
    public static final String URL_CITY= APP_URL+"getcity.php";

    public static final String URL_USER_DATA= APP_URL+"User/table_data";


}
